Martial Arts Studio | Yellow Umbrella Group

Doorway person removed. MCP cleanup removed 1,610 additional floating Gaussians.
684,429 retained Gaussians. The full-precision master preserves every retained source property.
Opens at the original View 4. Drag to look around. Scroll or pinch to zoom. Choose a viewpoint to move.
Camera translation is fixed at reviewed in-room stations.
The web payload was exported once from the lossless cleanup master, using the same SOG web format as the previous viewer.

META QUEST VR
Serve over HTTPS and open in Meta Quest Browser. Choose Enter VR.
Right trigger: next viewpoint. Left trigger: previous. Right stick: 30-degree snap turn. B: exit.
Native free locomotion is disabled. Head tracking remains natural. Moving away from a viewpoint fades the room until you return or change viewpoints.
Metric scan scale retained; estimated studio floor is Y=-0.76m.
Desktop navigation is unchanged. No additional scan compression.
Physical Quest 3 comfort/performance testing remains required.
