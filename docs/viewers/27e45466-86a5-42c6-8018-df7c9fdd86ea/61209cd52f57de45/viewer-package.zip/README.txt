Martial Arts Studio | Yellow Umbrella Group

Doorway person removed. MCP cleanup removed 1,610 additional floating Gaussians.
684,429 retained Gaussians. The full-precision master preserves every retained source property.
Opens at the original View 4. Drag to look around. Scroll or pinch to zoom. Choose a viewpoint to move.
Camera translation is fixed at reviewed in-room stations.
The web payload was exported once from the lossless cleanup master, using the same SOG web format as the previous viewer.
