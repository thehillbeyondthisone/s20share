Martial Arts Studio | Yellow Umbrella Group

Restored full-room scan with the doorway person removed.
Opens at the original View 4.
Drag to look around. Scroll or pinch to zoom. Choose an in-room viewpoint to move.
Camera translation is fixed at reviewed in-room stations. This is guided navigation, not a physical collision mesh.
The original person-free scan data is embedded unchanged.
