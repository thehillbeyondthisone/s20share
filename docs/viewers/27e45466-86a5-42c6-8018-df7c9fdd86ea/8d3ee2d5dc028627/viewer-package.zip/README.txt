Martial Arts Studio | Yellow Umbrella Group

Doorway person removed. Reviewed Oct 12 cleanup removed 9,476 more Gaussians from the previous published model.
674,953 retained Gaussians. The full-precision master preserves every retained source property.
Opens at the original View 4. Drag to look around. Scroll or pinch to zoom. Choose a viewpoint to move.
Camera translation is fixed at reviewed in-room stations.
The web payload was exported once from the lossless cleanup master, using the same SOG web format as the previous viewer.

META QUEST VR
Serve over HTTPS and open in Meta Quest Browser. Choose Enter VR.
Right trigger: next viewpoint. Left trigger: previous. Right stick: 30-degree snap turn. B: exit.
Native free locomotion is disabled. Head tracking remains natural. Moving away from a viewpoint fades the room until you return or change viewpoints.
Metric scan scale retained; estimated studio floor is Y=-0.76m.
Desktop navigation is unchanged. No additional scan compression.
Physical Quest 3 comfort/performance testing remains required.

The Oct 12 cleanup is local, reversible work in the Air Cleanup Progress project.
The broad-tail diagnostic layer was excluded from this publication. Some haze and surface softness remain.

Viewer fidelity fix: floating-point color accumulation enabled for the desktop/mobile browser view.
The exact Oct 12 SOG and all 674,953 Gaussians are unchanged. No extra cleanup, blur or model alteration.
Immersive WebXR uses the existing renderer path and has not been verified on a physical headset.
