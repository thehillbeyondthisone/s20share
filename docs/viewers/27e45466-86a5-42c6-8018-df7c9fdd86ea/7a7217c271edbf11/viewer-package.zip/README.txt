Martial Arts Studio | Yellow Umbrella Group

A studio-only walkthrough with four viewpoints around the pillar and training floor.
The adjoining laundry/tool room has been cropped from the scan.

Open index.html in a recent browser with WebGL support.
The scene, scripts and styles are embedded in the HTML.
Drag to look, scroll to zoom, or select a viewpoint to return to the studio.
