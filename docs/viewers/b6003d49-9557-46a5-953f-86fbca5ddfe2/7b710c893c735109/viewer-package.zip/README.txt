New S20 test scan | Yellow Umbrella Group

Open index.html in a recent browser with WebGL support.
The scene, scripts and styles are embedded in the HTML.
For a live link, upload index.html to a static web host (GitHub Pages or your existing site).
Review the entire walkthrough before client delivery.
